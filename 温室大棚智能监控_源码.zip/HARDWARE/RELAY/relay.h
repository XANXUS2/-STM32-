#ifndef __RELAY_H
#define __RELAY_H
#include "sys.h"

//�̵����˿ڶ���
#define RELAY1 PFout(0)	// IN1
#define RELAY2 PFout(1)	// IN2
#define RELAY3 PFout(2)	// IN3
#define RELAY4 PFout(3)	// IN4
#define RELAY5 PFout(4)	// IN5
#define RELAY6 PFout(5)	// IN6
#define RELAY7 PFout(6)	// IN7
#define RELAY8 PFout(13)	// IN8
#define RELAY9 PFout(14)	// IN9
#define RELAY10 PFout(15)	// IN10

void RELAY_Init(void);//��ʼ���̵���

#endif